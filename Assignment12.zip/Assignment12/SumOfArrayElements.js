function sumArray(arr) {
    return arr.reduce((sum, current) => sum + current, 0);
}
